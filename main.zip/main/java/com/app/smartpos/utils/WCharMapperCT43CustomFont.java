package com.app.smartpos.utils;

public class WCharMapperCT43CustomFont extends WCharMapperCT41{

}
